// ignore_for_file: unused_local_variable

import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:get/get.dart';
import 'package:get_storage/get_storage.dart';
import 'package:timezone/data/latest.dart' as tz;

import 'app/routes/app_pages.dart';

void main() async {
  WidgetsBinding widgetsBinding = WidgetsFlutterBinding.ensureInitialized();
  await ScreenUtil.ensureScreenSize();
  await Firebase.initializeApp(
    options: const FirebaseOptions(
      apiKey: "AIzaSyCC8MVfPtwC8uYEMULHjh1INQIh0vDwNw4",
      appId: "1:658625040700:android:b62101cb76f06183f4ce39",
      messagingSenderId: "658625040700",
      projectId: "feri-base",
      storageBucket: "feri-base.appspot.com",
    ),
  );
  await GetStorage.init();
  tz.initializeTimeZones();
  runApp(
    ScreenUtilInit(
      designSize: const Size(414, 896),
      builder: (_, __) => GetMaterialApp(
        debugShowCheckedModeBanner: false,
        title: "Feri",
        initialRoute: AppPages.INITIAL,
        getPages: AppPages.routes,
        theme: ThemeData(
          appBarTheme: const AppBarTheme(
            elevation: 0,
            backgroundColor: Colors.white,
            iconTheme: IconThemeData(color: Colors.black),
            titleTextStyle: TextStyle(
              color: Colors.black,
              fontSize: 18,
            ),
          ),
          fontFamily: "Poppins",
          colorScheme: ColorScheme.fromSwatch(primarySwatch: Colors.red)
              .copyWith(background: Colors.white),
        ),
      ),
    ),
  );
}
