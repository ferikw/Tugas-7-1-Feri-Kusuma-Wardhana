import 'package:flutter/material.dart';

const mainColor = Color(0xFFFFCC00);
const white = Color(0xFFFFFFFF);
final grey400 = Colors.grey[400];

Color getColor(String jenis) {
  if (jenis == "Makanan") {
    return Colors.green;
  } else if (jenis == "Minuman") {
    return const Color.fromARGB(255, 108, 12, 185);
  } else {
    return Colors.red;
  }
}
