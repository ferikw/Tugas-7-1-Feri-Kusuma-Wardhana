import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:get_storage/get_storage.dart';
import 'package:feri_kusuma_wardhana_7_1/app/utils/notifications_api.dart';

class SettingPageController extends GetxController {
  final RxBool sarapanToggle = false.obs;
  final RxBool siangToggle = false.obs;
  final RxBool malamToggle = false.obs;

  final GetStorage box = GetStorage();

  @override
  void onInit() async {
    super.onInit();
    await NotificationApi.init();

    if (box.read('sarapan') != null) {
      sarapanToggle.value = box.read('sarapan');
    }
    if (box.read('siang') != null) {
      siangToggle.value = box.read('siang');
    }
    if (box.read('malam') != null) {
      malamToggle.value = box.read('malam');
    }
  }

  Future<void> toggleSarapan() async {
    sarapanToggle.toggle();
    box.write("sarapan", sarapanToggle.value);
    if (sarapanToggle.value) {
      await NotificationApi.scheduledNotification(
        id: 1,
        title: "Jangan Lupa Sarapan",
        body: "Yuk cek resep di katalog!",
        payload: "sarapan",
        hour: 7,
        minute: 0,
      ).then((value) {
        Get.snackbar(
          "Berhasil",
          "Pengingat sarapan berhasil diaktifkan",
          snackPosition: SnackPosition.BOTTOM,
          backgroundColor: Colors.green,
          colorText: Colors.white,
        );
      });
    } else {
      NotificationApi.cancelNotification(1).then((value) {
        Get.snackbar(
          "Berhasil",
          "Pengingat sarapan berhasil dinonaktifkan",
          snackPosition: SnackPosition.BOTTOM,
          backgroundColor: Colors.red,
          colorText: Colors.white,
        );
      });
    }
  }

  Future<void> toggleSiang() async {
    siangToggle.toggle();
    box.write("siang", siangToggle.value);
    if (siangToggle.value) {
      await NotificationApi.scheduledNotification(
        id: 2,
        title: "Lets have lunch!",
        body: "Lihat resep makanan siang hari ini",
        payload: "siang",
        hour: 12,
        minute: 0,
      ).then((value) {
        Get.snackbar(
          "Berhasil",
          "Pengingat makan siang berhasil diaktifkan",
          snackPosition: SnackPosition.BOTTOM,
          backgroundColor: Colors.green,
          colorText: Colors.white,
        );
      });
    } else {
      NotificationApi.cancelNotification(2).then((value) {
        Get.snackbar(
          "Berhasil",
          "Pengingat makan siang berhasil dinonaktifkan",
          snackPosition: SnackPosition.BOTTOM,
          backgroundColor: Colors.red,
          colorText: Colors.white,
        );
      });
    }
  }

  Future<void> toggleMalam() async {
    malamToggle.toggle();
    box.write("malam", malamToggle.value);
    if (malamToggle.value) {
      await NotificationApi.scheduledNotification(
        id: 3,
        title: "Yuk Dinner",
        body: "Jangan lupa makan malam ya, nanti tidurnya akan lebih nyenyak",
        payload: "malam",
        hour: 18,
        minute: 0,
      ).then((value) {
        Get.snackbar(
          "Berhasil",
          "Pengingat makan malam berhasil diaktifkan",
          snackPosition: SnackPosition.BOTTOM,
          backgroundColor: Colors.green,
          colorText: Colors.white,
        );
      });
    } else {
      NotificationApi.cancelNotification(3).then((value) {
        Get.snackbar(
          "Berhasil",
          "Pengingat makan malam berhasil dinonaktifkan",
          snackPosition: SnackPosition.BOTTOM,
          backgroundColor: Colors.red,
          colorText: Colors.white,
        );
      });
    }
  }
}
